# cpscam
Bypass captive portals by impersonating inactive users

# Info
Updated version of Joshua Wright's cpscam utility located at http://www.willhackforsushi.com/code/cpscam.pl.

I added support for setting the ethernet interface and captive portal logoff URL on the command line.

# Usage
perl cpscam.pl &lt;ethX&gt; &lt;ListenIP&gt; &lt;SubnetMask&gt; &lt;InactivityTimeout&gt; &lt;CaptiveLogoffURL&gt; 
